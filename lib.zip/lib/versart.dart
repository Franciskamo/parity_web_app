class Versandart {
  final String vsaNr;
  final String vsaBez;

  Versandart({
    required this.vsaNr,
    required this.vsaBez,
  });

  factory Versandart.fromJson(Map<String, dynamic> json) {
    return Versandart(
      vsaNr: json['vsaNr'] ?? '',
      vsaBez: json['vsaBez'] ?? '',
    );
  }
}
