class Lieferbedingung {
  final String lbdNr;
  final String lbdBez;

  Lieferbedingung({
    required this.lbdNr,
    required this.lbdBez,
  });

  factory Lieferbedingung.fromJson(Map<String, dynamic> json) {
    return Lieferbedingung(
      lbdNr: json['lbdNr'] ?? '',
      lbdBez: json['lbdBez'] ?? '',
    );
  }
}
