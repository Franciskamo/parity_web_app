class Zahlbedingung {
  final String zbdNr;
  final String zbdBez;

  Zahlbedingung({required this.zbdNr, required this.zbdBez});

  factory Zahlbedingung.fromJson(Map<String, dynamic> json) {
    return Zahlbedingung(
      zbdNr: json['zbdNr'],
      zbdBez: json['zbdBez'],
    );
  }
}
