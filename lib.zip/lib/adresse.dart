
class Adresse {
  final String ansnr;
  final String name;
  final String strasse;
  final String ort;
  final String plz;
  final String land;
  final String telefon;
  final String fax;
  final String email;
  final String homepage;

  Adresse({
    required this.ansnr,
    required this.name,
    required this.strasse,
    required this.ort,
    required this.plz,
    required this.land,
    required this.telefon,
    required this.fax,
    required this.email,
    required this.homepage,
  });

  factory Adresse.fromJson(Map<String, dynamic> json) {
    return Adresse(
      ansnr: json['ansnr']?.toString() ?? '',
      name: json['name001']?.toString() ?? '',
      strasse: json['strasse']?.toString() ?? '',
      ort: json['ort']?.toString() ?? '',
      plz: json['plz']?.toString() ?? '',
      land: json['land']?.toString() ?? '',
      telefon: json['ansTelefon']?.toString() ?? '',
      fax: json['ansTelefax']?.toString() ?? '',
      email: json['ansEmail']?.toString() ?? '',
      homepage: json['ansHomepage']?.toString() ?? '',
    );
  }

  static Adresse leer() {
    return Adresse(
      ansnr: '',
      name: '',
      strasse: '',
      ort: '',
      plz: '',
      land: '',
      telefon: '',
      fax: '',
      email: '',
      homepage: '',
    );
  }
}
