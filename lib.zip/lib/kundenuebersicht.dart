
import 'package:flutter/material.dart';
import 'api_service.dart'; 
import 'kundendetails.dart';

class Kundenuebersicht extends StatefulWidget {
  final KundeMitAdresse? kunde;

  const Kundenuebersicht({Key? key, required this.kunde}) : super(key: key);

  @override
  State<Kundenuebersicht> createState() => _KundenuebersichtState();
}

class _KundenuebersichtState extends State<Kundenuebersicht> {
  Kundendetails? details;
  bool istLaden = true;

  @override
  void initState() {
    super.initState();
    ladeDaten();
  }

  Future<void> ladeDaten() async {
    final daten = await ladeKundendetails(widget.kunde!.kundennummer);
    setState(() {
      details = daten;
      istLaden = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (istLaden || details == null) {
      return const Center(child: CircularProgressIndicator());
    }

    final d = details!;

    return Scaffold(
      appBar: AppBar(title: Text("Kundenübersicht")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Name: ${d.name}", style: TextStyle(fontSize: 18)),
            Text("Adresse: ${d.strasse}, ${d.plz} ${d.ort}, ${d.land}"),
            Text("Telefon: ${d.telefon}"),
            Text("E-Mail: ${d.email}"),
            Text("Webseite: ${d.homepage}"),
            SizedBox(height: 16),
            Text("Zahlungsbedingung: ${d.zahlungsbedingung}"),
            Text("Lieferbedingung: ${d.lieferbedingung}"),
            Text("Versandart: ${d.versandart}"),
          ],
        ),
      ),
    );
  }
}
