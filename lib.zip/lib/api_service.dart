import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'adresse.dart';
import 'kunde.dart';
import 'kundendetails.dart';
import 'zahlbed.dart';
import 'liefbed.dart';
import 'versart.dart';


Future<Kundendetails> ladeKundendetails(String kundennummer) async {
  final prefs = await SharedPreferences.getInstance();
  final token = prefs.getString('token');

  final headers = {'Authorization': 'Bearer $token'};

  // 1. Alle Daten holen
  final kundenRes = await http.get(Uri.parse('https://api.parity-software.com/api/v1/kunden'), headers: headers);
  final adressenRes = await http.get(Uri.parse('https://api.parity-software.com/api/v1/adressen'), headers: headers);
  final zahlbedRes = await http.get(Uri.parse('https://api.parity-software.com/api/v1/zahlungsbedingungen'), headers: headers);
  final liefbedRes = await http.get(Uri.parse('https://api.parity-software.com/api/v1/liefbedingungen'), headers: headers);
  final versartRes = await http.get(Uri.parse('https://api.parity-software.com/api/v1/versandart'), headers: headers);

  final kunden = (jsonDecode(kundenRes.body) as List).map((e) => Kunde.fromJson(e)).toList();
  final adressen = (jsonDecode(adressenRes.body) as List).map((e) => Adresse.fromJson(e)).toList();
  final zahlbedingungen = (jsonDecode(zahlbedRes.body) as List).map((e) => Zahlbedingung.fromJson(e)).toList();
  final lieferbedingungen = (jsonDecode(liefbedRes.body) as List).map((e) => Lieferbedingung.fromJson(e)).toList();
  final versandarten = (jsonDecode(versartRes.body) as List).map((e) => Versandart.fromJson(e)).toList();

  // 2. Den richtigen Kunden finden
  final kunde = kunden.firstWhere((k) => k.kontonummer == kundennummer);
  final adresse = adressen.firstWhere((a) => a.ansnr == kunde.kontonummer, orElse: () => Adresse.leer());

  final zahlbed = zahlbedingungen.firstWhere((z) => z.zbdNr == kunde.kdnZbnr, orElse: () => Zahlbedingung(zbdNr: '', zbdBez: ''));
  final liefbed = lieferbedingungen.firstWhere((l) => l.lbdNr == kunde.kdnLbdnr, orElse: () => Lieferbedingung(lbdNr: '', lbdBez: ''));
  final versart = versandarten.firstWhere((v) => v.vsaNr == kunde.kdnVsnr, orElse: () => Versandart(vsaNr: '', vsaBez: ''));

  return Kundendetails(
    kundennummer: kunde.kontonummer,
    name: adresse.name,
    strasse: adresse.strasse,
    ort: adresse.ort, 
    plz: adresse.plz,
    land: adresse.land,
    telefon: adresse.telefon,
    fax: adresse.fax,
    email: adresse.email,
    homepage: adresse.homepage,
    zahlungsbedingungNr: zahlbed.zbdNr,
    zahlungsbedingung: zahlbed.zbdBez,
    lieferbedingungNr: liefbed.lbdNr,
    lieferbedingung: liefbed.lbdBez,
    versandartNr: versart.vsaNr,
    versandart: versart.vsaBez,
  );
}

class KundeMitAdresse {
  final String kundennummer;
  final String name;
  final String telefon;
  final String email;

  KundeMitAdresse({
    required this.kundennummer,
    required this.name,
    required this.telefon,
    required this.email,
  });
}

Future<List<KundeMitAdresse>> ladeKombinierteKunden() async {
  final prefs = await SharedPreferences.getInstance();
  final token = prefs.getString('token');

  final kundenResponse = await http.get(
    Uri.parse('https://api.parity-software.com/api/v1/kunden'),
    headers: {'Authorization': 'Bearer $token'},
  );

  final adressenResponse = await http.get(
    Uri.parse('https://api.parity-software.com/api/v1/adressen'),
    headers: {'Authorization': 'Bearer $token'},
  );

  final kundenJson = json.decode(kundenResponse.body) as List;
  final adressenJson = json.decode(adressenResponse.body) as List;

  final kunden = kundenJson.map((k) => Kunde.fromJson(k)).toList();
  final adressen = adressenJson.map((a) => Adresse.fromJson(a)).toList();

  List<KundeMitAdresse> kombiniert = [];

  for (Kunde kunde in kunden) {
    Adresse adresse = adressen.firstWhere(
      (a) => a.ansnr == kunde.kdnLfdnr,
      orElse: () => Adresse.leer(),
    );

    kombiniert.add(KundeMitAdresse(
      kundennummer: kunde.kontonummer,
      name: adresse.name,
      telefon: adresse.telefon,
      email: adresse.email,
    ));
  }

  return kombiniert;
}

  final kundenResponse = await http.get(
    Uri.parse('https://api.parity-software.com/api/v1/kunden'),
    headers: {'Authorization': 'Bearer $token'},
  );

  final adressenResponse = await http.get(
    Uri.parse('https://api.parity-software.com/api/v1/adressen'),
    headers: {'Authorization': 'Bearer $token'},
  );

  final kundenJson = json.decode(kundenResponse.body);
  final adressenJson = json.decode(adressenResponse.body);

  final kundenJsonList = (kundenJson as List);
  print('API liefert Kunden: ${kundenJsonList.length}');

  if (kundenJsonList.isNotEmpty) {
  print('Beispielkunde: ${kundenJsonList[0]}');
}

  final gefiltert = kundenJsonList
    .where((k) => k['id'] != null && k['kdnKontonr'] != null)
    .toList();
  print('Nach Filter übrig: ${gefiltert.length}');

  final kunden = gefiltert
      .map((k) => Kunde.fromJson(k))
      .toList();


  final adressen = (adressenJson as List)
      .map((a) => Adresse.fromJson(a))
      .toList();

  List<KundeMitAdresse> kombiniert = [];

  for (Kunde kunde in kunden) {
    Adresse? adresse;
    try {
      adresse = adressen.firstWhere(
        (a) => a.ansnr.toString() == kunde.lfdnr.toString(),
        orElse: () => Adresse.leer(),
      );

    } catch (e) {
      adresse = null;
    }

    kombiniert.add(
      KundeMitAdresse(
        kundennummer: kunde.kontonummer,
        name: adresse?.name ?? 'keine Adresse vorhanden',
        telefon: adresse?.telefon ?? '-',
        email: adresse?.email ?? '-',
      ),
    );
  }

  return kombiniert;
}