
class Kunde {
  final String kdnLfdnr;
  final String kontonummer;
  final String kdnZbnr;
  final String kdnLbdnr;
  final String kdnVsnr;

  Kunde({
    required this.kdnLfdnr,
    required this.kontonummer,
    required this.kdnZbnr,
    required this.kdnLbdnr,
    required this.kdnVsnr,
  });

  factory Kunde.fromJson(Map<String, dynamic> json) {
    return Kunde(
      kdnLfdnr: json['kdnLfdnr']?.toString() ?? '',
      kontonummer: json['kdnKontonr']?.toString() ?? '',
      kdnZbnr: json['kdnZbnr']?.toString() ?? '',
      kdnLbdnr: json['kdnLbdnr']?.toString() ?? '',
      kdnVsnr: json['kdnVsanr']?.toString() ?? '',
    );
  }
}
